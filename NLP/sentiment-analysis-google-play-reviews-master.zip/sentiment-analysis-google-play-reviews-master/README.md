# sentiment-analysis-google-play-reviews

Open the project in a colab notebook 
<a href="https://colab.research.google.com/drive/1MxGXO-OfWp1lujIwchO88HXYWCmgRMKi#scrollTo=ynGUsi-I7ugJ">
  <img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/>
</a>


Sentiment Prediction of Google Play Store Reviews with Tensorflow 2.0
